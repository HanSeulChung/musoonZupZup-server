const express = require('express');
const app = express();
const helmet = require('helmet');
const cors = require('cors');
const http = require('http');

// const corsOptions = {
//     origin: ['https://maint.bigddex.com', 'https://relay.bigddex.com', 'https://black.bigddex.com', 'http://localhost:3000'],
//     methods: ['GET', 'POST', 'PUT', 'DELETE'],
//     allowedHeaders: ['Content-Type', 'Authorization'],
//     credentials: true,
// }
app.use(cors(/*corsOptions*/));

const port = process.env.PORT || 3000;

app.use(helmet());


require('dotenv').config();

app.use(express.urlencoded({ extended: true }));

// // 라우터 경로 설정
const Router = require('./src/app');

app.use('/api', Router);

app.use('/', (req, res) => {
    res.status(200).json('HTTP OK');
    console.log('ok');
})

app.use((req, res, next) => {
    const error = new Error('Not found');
    console.log(req.url)
    error.status = 404;
    next(error);
});

const server = http.createServer(app);

server.listen(port, (err) => {
    if (err) console.log(err);
    console.log(`서버가 가동중입니다. 포트 :  ${port}`);
});
