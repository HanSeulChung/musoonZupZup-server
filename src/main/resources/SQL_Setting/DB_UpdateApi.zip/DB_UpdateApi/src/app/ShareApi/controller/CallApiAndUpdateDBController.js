const router = require('express').Router();
const modules = require('../service/CallApiAndUpdateDBService');

/* 
 * 공공 데이터 API 를 호출 후 ( 무순위 청약 정보 ) 
 * 해당 청약의 공급 금액을 타 API 를 통해 호출 후 이를 DB 에 저장한다. 
*/
router.use('/update', async (req, res) => {
    try {
       
        modules.getAllpblanc();

        return res.status(200).json("ok");
    } catch (e) {
        return res.status(400).json("Bad Request");
    }
});

module.exports = router;