const router = require('express').Router();

// 주소 유사도
const address = require('./controller/CallApiAndUpdateDBController');
router.use('/call', address);

// test 
const test = require('./test/test');
router.use('/test', test);

router.use('/', (req, res, next) => {
    console.log('idx')
    next();
})

module.exports = router;
