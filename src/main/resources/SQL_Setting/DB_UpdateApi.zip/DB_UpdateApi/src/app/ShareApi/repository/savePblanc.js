const db = require('../../../lib/database');

/*
    정제된 데이터를 DB 에 삽입한다. 
*/
const insertPblanc = async(pblanc) => {
    try{ 
        // 1. 중복된 정보가 있는지 확인 
        if(await checkDuplicatePblanc(pblanc.house_manage_no)) return;
        
        // 2. 중복된 정보가 없다면 삽입 
        const insertQuery = `INSERT INTO apply_home VALUE 
        (NULL, ?, ?, DEFAULT, DEFAULT,?, ?, ?, ?, ?, null,?, ?, ?, ?, ?, ?, ?, ?, ?, DEFAULT, DEFAULT);`

        await db.query(insertQuery, [
            pblanc.house_manage_no,
            pblanc.pblanc_no,
            pblanc.house_name,
            pblanc.house_code,
            pblanc.zip_code,
            pblanc.sido_code,
            pblanc.house_address,
            pblanc.suply_count,
            pblanc.suply_price,
            pblanc.pblanc_date,
            pblanc.apply_start_date,
            pblanc.apply_end_date,
            pblanc.apply_announce_date,
            pblanc.business_entity,
            pblanc.business_tel,
            pblanc.applyhome_url
        ]);
    } catch (e) {
        console.log(e);
    }
}

const checkDuplicatePblanc = async (house_manage_no) => {
    try {
        const selectQuery = `SELECT COUNT(*) AS 'cnt' FROM apply_home WHERE house_manage_no = ?;`;
        
        const result = await db.query(selectQuery, [house_manage_no]);
        
        // 중복 여부 boolean 값 반환 
        return result[0].cnt > 0;
    } catch(e) {
        console.log(e);
    }
}

module.exports = { insertPblanc };