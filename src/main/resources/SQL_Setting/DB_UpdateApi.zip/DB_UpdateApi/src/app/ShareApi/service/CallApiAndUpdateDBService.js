const axios = require('axios')
const reposiroty = require('../repository/savePblanc')

// 딜레이 함수 (ms 단위로 딜레이 시간 설정)
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/*
    모든 무순위 청약 정보를 가져온다. 
*/
const getAllpblanc = async () => {
	// 약 5000 개 정도의 정보를 채운다.
	// for(let i=0; i<500; i++) {
	// 1. 무순위 청약 정보를 가져온다.
	// const url = `https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/getRemndrLttotPblancDetail?page=${(i * 40 + 1)}&perPage=${(i * 40 + 40)}&serviceKey=DA1AAMAjmL1A%2B93AWBfGWukdX0PrnP0FtN8dclnh7OleXvtF3hv164Xn5sANSNPCxfH0tq%2FecoNb4Gu0oVLVng%3D%3D`;
	const url =
		'https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/getRemndrLttotPblancDetail?page=1&perPage=10000&serviceKey=DA1AAMAjmL1A%2B93AWBfGWukdX0PrnP0FtN8dclnh7OleXvtF3hv164Xn5sANSNPCxfH0tq%2FecoNb4Gu0oVLVng%3D%3D'
	// 요청 URL을 로그로 출력
	console.log(`Requesting URL: ${url}`)

	const response = await axios.get(url)

	// 1-1. 무순위 청약 정보의 data (배열) 부분만 가져온다.
	const pblancList = response.data.data
	// console.log(pblancList)
	// 1-2. 무순위 청약 정보를 바탕으로 정제된 데이터를 생성한다.
	let refinedPblancList = []

	// 1-3. 무순위 청약 정보를 바탕으로 정제 데이터를 저장한다.
	for (const e of pblancList) {
		// 1-3-1. 같은 청약 내역 중 가장 비싼 공급 금액을 가져온다.
		const maxPrice = await getSuplyPrice(e.HOUSE_MANAGE_NO, e.PBLANC_NO)

		refinedPblancList.push({
			house_manage_no: e.HOUSE_MANAGE_NO,
			pblanc_no: e.PBLANC_NO,
			house_name: e.HOUSE_NM,
			house_code: e.HOUSE_SECD,
			zip_code: e.HSSPLY_ZIP,
			sido_code: getSidoCode(e.HSSPLY_ADRES),
			house_address: e.HSSPLY_ADRES,
			suply_count: e.TOT_SUPLY_HSHLDCO,
			suply_price: maxPrice,
			pblanc_date: e.RCRIT_PBLANC_DE,
			apply_start_date: e.SUBSCRPT_RCEPT_BGNDE,
			apply_end_date: e.SUBSCRPT_RCEPT_ENDDE,
			apply_announce_date: e.PRZWNER_PRESNATN_DE,
			business_entity: e.BSNS_MBY_NM,
			business_tel: e.MDHS_TELNO,
			applyhome_url: e.PBLANC_URL.replace('https://www.applyhome.co.kr/ai/aia', ''),
		})
		// }
		// console.log(refinedPblancList);

		// 1-4. 데이터를 저장한다.
		for (const e of refinedPblancList) {
			await reposiroty.insertPblanc(e)
		}

		// 각 페이지 요청 후 1초 딜레이
		await delay(1000) // 1000ms = 1초 딜레이
	}
}

/*
    무순위 청약의 주택 관리 번호와, 공고 번호 로 공급 가격을 가져온다. 
*/
const getSuplyPrice = async (house_manage_no, pblanc_no) => {
	const response = await axios.get(
		`https://api.odcloud.kr/api/ApplyhomeInfoDetailSvc/v1/getRemndrLttotPblancMdl?page=1&perPage=10&cond%5BHOUSE_MANAGE_NO%3A%3AEQ%5D=${house_manage_no}&cond%5BPBLANC_NO%3A%3AEQ%5D=${pblanc_no}&serviceKey=DA1AAMAjmL1A%2B93AWBfGWukdX0PrnP0FtN8dclnh7OleXvtF3hv164Xn5sANSNPCxfH0tq%2FecoNb4Gu0oVLVng%3D%3D`
	)
	// console.log(response.data.data);

	const pblanc = response.data.data
	let maxPrice = -1
	pblanc.forEach((e) => {
		maxPrice = Math.max(e.LTTOT_TOP_AMOUNT, maxPrice)
	})

	return maxPrice
}

/*
    주소를 기준으로 sido_code 를 추출한다. 
*/
const getSidoCode = (addr) => {
	const sido = addr.trim().split(' ')[0]

	let sidoCode

	switch (sido.trim().replace(' ', '')) {
		case '서울특별시':
		case '서울':
			sidoCode = 100
			break
		case '강원도':
		case '강원특별자치도':
			sidoCode = 200
			break
		case '대전광역시':
		case '대전':
			sidoCode = 300
			break
		case '충청남도':
		case '충남':
			sidoCode = 312
			break
		case '세종특별자치시':
		case '행정중심복합도시':
		case '세종':
		case '세종시':
			sidoCode = 338
			break
		case '충청북도':
		case '충북':
			sidoCode = 360
			break
		case '인천광역시':
		case '인천':
			sidoCode = 400
			break
		case '경기도':
		case '경기':
		case '안양동':
		case '수원시':
		case '평택':
			sidoCode = 410
			break
		case '광주광역시':
		case '광주':
			sidoCode = 500
			break
		case '전라남도':
		case '전남':
			sidoCode = 513
			break
		case '전라북도':
		case '전북특별자치도':
		case '전북':
			sidoCode = 560
			break
		case '부산광역시':
		case '부산':
			sidoCode = 600
			break
		case '경상남도':
		case '경남':
			sidoCode = 621
			break
		case '울산광역시':
		case '울산':
			sidoCode = 680
			break
		case '제주특별자치도':
		case '제주도':
		case '재주':
			sidoCode = 690
			break
		case '대구광역시':
		case '대구':
		case '안심뉴타운':
		case '유천동':
			sidoCode = 700
			break
		case '경상북도':
		case '경북':
			sidoCode = 712
			break
	}

	return sidoCode
}

module.exports = { getAllpblanc }
