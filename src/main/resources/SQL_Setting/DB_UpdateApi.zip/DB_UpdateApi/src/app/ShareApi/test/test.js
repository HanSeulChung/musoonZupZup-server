const router = require('express').Router();
const axios = require('axios');

router.use('/test', async (req, res) => {
    try {
        const result = await getAllpblanc();
        
        return res.status(200).json({
            mgs : result
        });
    } catch (e) {
        return res.status(400).json("Bad Request");
    }
});

/*
    모든 무순위 청약 정보를 가져온다. 
*/
const getAllpblanc = async () => {
    const response = await axios.get('https://api.odcloud.kr/api/15128105/v1/uddi:d084bc01-f419-45ac-8555-bcd270c4b656?page=1&perPage=5&serviceKey=DA1AAMAjmL1A%2B93AWBfGWukdX0PrnP0FtN8dclnh7OleXvtF3hv164Xn5sANSNPCxfH0tq%2FecoNb4Gu0oVLVng%3D%3D');
    
    return response.data
}

module.exports = router;