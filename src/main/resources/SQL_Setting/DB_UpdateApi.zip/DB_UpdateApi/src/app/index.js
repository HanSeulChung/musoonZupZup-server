const router = require('express').Router();

// openApi
const openApi = require('./ShareApi');
router.use('/open', openApi);

router.use('/', (req, res, next) => {
    console.log('idx')
    next();
})

module.exports = router;


//--------------------------------------
